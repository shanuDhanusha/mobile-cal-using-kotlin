package com.example.calculeter

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Switch
import android.widget.TextView
import net.objecthunter.exp4j.ExpressionBuilder
import org.w3c.dom.Text
import java.lang.Exception


class MainActivity : AppCompatActivity() {

    lateinit var inputValue:TextView;
    lateinit var outputResalt:TextView;
    lateinit var dilitebut:Button;
    lateinit var canslebut:Button;
    lateinit var dividbut:Button;
    lateinit var addbut:Button;
    lateinit var subbut:Button;
    lateinit var multiplebut:Button;
    lateinit var modbut:Button;
    lateinit var dotbut:Button;
    lateinit var equlebut:Button;
    lateinit var but1:Button;
    lateinit var but2:Button;
    lateinit var but3:Button;
    lateinit var but4:Button;
    lateinit var but5:Button;
    lateinit var but6:Button;
    lateinit var but7:Button;
    lateinit var but8:Button;
    lateinit var but9:Button;
    lateinit var but0:Button;
    //we can concat all expression by this string
   public final  lateinit var concatstring:String
    //result string
    //lateinit var resultString: String



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //link find by id
        inputValue=findViewById(R.id.calvalue)
        outputResalt=findViewById(R.id.result)
        dilitebut=findViewById(R.id.ac)
        canslebut=findViewById(R.id.cancle)
        dividbut=findViewById(R.id.div)
        addbut=findViewById(R.id.add)
        subbut=findViewById(R.id.sub)
        multiplebut=findViewById(R.id.mul)
       // multiplebut=findViewById(R.id.mul)
        equlebut=findViewById(R.id.resultbut)
        modbut=findViewById(R.id.mod)
        dotbut=findViewById(R.id.dot)
       // dotbut=findViewById(R.id.dot)
        but0=findViewById(R.id.but0)
        but1=findViewById(R.id.but1)
        but2=findViewById(R.id.but2)
        but3=findViewById(R.id.but3)
        but4=findViewById(R.id.but4)
        but5=findViewById(R.id.but5)
        but6=findViewById(R.id.but6)
        but7=findViewById(R.id.but7)
        but8=findViewById(R.id.but8)
        but9=findViewById(R.id.but9)
        equlebut=findViewById(R.id.resultbut)
         //frist asing value
         concatstring=""

        dilitebut.setOnClickListener {
            inputValue.setText("")
            outputResalt.setText("=")
            concatstring=""
        }
        canslebut.setOnClickListener {
          concatstring=  concatstring.dropLast(1)
            inputValue.setText(concatstring)
        }
        dividbut.setOnClickListener {
           concatstring=concatstring +"/"
            inputValue.setText(concatstring)
            //println(input)
        }
        addbut.setOnClickListener {
            concatstring=concatstring+"+"
            inputValue.setText(concatstring)
        }
        subbut.setOnClickListener {
            concatstring=concatstring+"-"
            inputValue.setText(concatstring)
        }
        multiplebut.setOnClickListener {
            concatstring=concatstring+"*"
            inputValue.setText(concatstring)
        }
        modbut.setOnClickListener {
            concatstring=concatstring+"%"
            inputValue.setText(concatstring)
        }
        dotbut.setOnClickListener {
            concatstring=concatstring+"."
            inputValue.setText(concatstring)
        }
        but0.setOnClickListener {
            concatstring=concatstring+"0"
            inputValue.setText(concatstring)
        }
        but1.setOnClickListener {
            concatstring=concatstring+"1"
            inputValue.setText(concatstring)
        }
        but2.setOnClickListener {
            concatstring=concatstring+"2"
            inputValue.setText(concatstring)
        }
        but3.setOnClickListener {
            concatstring=concatstring+"3"
            inputValue.setText(concatstring)
        }
        but4.setOnClickListener {
            concatstring=concatstring+"4"
            inputValue.setText(concatstring)
        }
        but5.setOnClickListener {
            concatstring=concatstring+"5"
            inputValue.setText(concatstring)
        }
        but6.setOnClickListener {
            concatstring=concatstring+"6"
            inputValue.setText(concatstring)
        }
        but7.setOnClickListener {
            concatstring=concatstring+"7"
            inputValue.setText(concatstring)
        }
        but8.setOnClickListener {
            concatstring=concatstring+"8"
            inputValue.setText(concatstring)
        }
        but9.setOnClickListener {
            concatstring=concatstring+"9"
            inputValue.setText(concatstring)
        }
          equlebut.setOnClickListener {
               addExpression()
            }



    }

    //logic function

    fun addExpression(){
       if(!concatstring.isEmpty()) {
           try {
               var result: Double = ExpressionBuilder(concatstring).build().evaluate()
               outputResalt.setText("="+result.toString())
           }catch (e:Exception){
                outputResalt.setText("="+"infinity")
           }

       }


    }

}